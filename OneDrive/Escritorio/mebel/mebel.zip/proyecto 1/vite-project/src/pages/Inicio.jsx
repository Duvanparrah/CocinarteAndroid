const Inicio =()=> {
    return(
        <>
        <h1 className="bg-red-600">hola mundo</h1>
        </>
    )
}
export default Inicio;