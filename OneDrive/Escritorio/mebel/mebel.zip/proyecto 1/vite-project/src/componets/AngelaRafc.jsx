const AngelaRafc = (props) => {
  return (
    <div>AngelaRafc</div>
  )
}

export default AngelaRafc;