function Angelabutton(){
    const varNombre = 'angela'
    return(
        <>
        <button className="bg-black px-5 py-2 text-white">{varNombre}</button>
        
        </>
    )
}
export default Angelabutton;
