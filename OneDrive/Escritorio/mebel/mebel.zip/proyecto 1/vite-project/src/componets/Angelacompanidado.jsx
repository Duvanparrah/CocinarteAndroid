export const Angelacompanidado = (props) => {
  return (
    <>
    <section className="bg-zinc-500 w-5/6 mx-auto px-8 pt-10">
    {props.children}
    </section>
    
    </>
  )
}
export default Angelacompanidado;
     