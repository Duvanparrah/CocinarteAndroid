export const Angelacompanidado2 = (props) => {
    return (
      <>
      <section className="bg-red-500 w-5/6 mx-auto px-8 pt-10">
      {props.children}
      </section>
      
      </>
    )
  }
  export default Angelacompanidado2;