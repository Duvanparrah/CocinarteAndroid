package com.camilo.cocinarte.models;

public class PlanRequest {
}
