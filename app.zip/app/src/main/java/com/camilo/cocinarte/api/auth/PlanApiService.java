package com.camilo.cocinarte.api.auth;

public class PlanApiService {
}
