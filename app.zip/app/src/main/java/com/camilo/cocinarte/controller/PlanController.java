package com.camilo.cocinarte.controller;

public class PlanController {
}
